export default async function getConnectedAccountDetails({ apiClient }) {
  const rawFields = await apiClient.get('about', { fields: 'user' })
  const {
    user: { displayName, emailAddress },
  } = rawFields
  return { name: displayName, email: emailAddress, rawFields }
}
