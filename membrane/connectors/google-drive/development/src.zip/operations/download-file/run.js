export default async function downloadFile({
  apiClient,
  input,
  engineApiClient,
}) {
  const exportTypeDefaults = {
    'application/vnd.google-apps.document':
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.google-apps.spreadsheet':
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.google-apps.presentation':
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.google-apps.drawing': 'application/pdf',
    'application/vnd.google-apps.form': 'application/zip',
    'application/vnd.google-apps.script':
      'application/vnd.google-apps.script+json',
    'application/vnd.google-apps.jam': 'application/pdf',
    'application/vnd.google-apps.site': 'text/plain',
    'application/vnd.google-apps.mail-layout': 'text/plain',
    'application/vnd.google-apps.vid': 'video/mp4',
  }

  const query = { supportsAllDrives: true }
  const metadata = await apiClient.get(
    `/files/${input.fileId}?fields=mimeType,exportLinks`,
    query,
  )

  let path

  if (metadata.exportLinks && Object.keys(metadata.exportLinks).length > 0) {
    // Find a preferred format for exporting
    const exportMimeType =
      input.exportAs || exportTypeDefaults[metadata.mimeType]
    if (exportMimeType && metadata.exportLinks[exportMimeType]) {
      path = metadata.exportLinks[exportMimeType]
    } else {
      // If doesn't exist - pick the first available
      path = metadata.exportLinks[Object.keys(metadata.exportLinks)[0]]
    }
  } else if (Object.keys(exportTypeDefaults).includes(metadata.mimeType)) {
    // Fallback / another mechanism: export Google Docs file into a preferred format.
    const exportAs = input.exportAs || exportTypeDefaults[metadata.mimeType]
    path = `/files/${input.fileId}/export`
    query.mimeType = exportAs
  } else {
    path = `/files/${input.fileId}`
    query.alt = 'media'
  }

  const fileResponse = await apiClient.makeApiRequest({
    path,
    query,
    method: 'get',
    responseType: 'stream',
    returnFullResponse: true,
  })

  const response = await engineApiClient.post('/files', fileResponse.data, {
    headers: {
      'Content-Length': fileResponse.headers['content-length'],
      'Content-Type': fileResponse.headers['content-type'],
    },
    // Without this, we load the whole file into memory (which can be several GB).
    // https://github.com/axios/axios/issues/1045
    maxRedirects: 0,
  })
  return {
    downloadUri: response.downloadUri,
  }
}
