import axios from 'axios'

export default async function uploadFile({
  apiClient,
  input: { fileName, fileUri, folderId },
}) {
  const path = 'https://www.googleapis.com/upload/drive/v3/files'
  const query = { uploadType: 'resumable' }
  const data = {
    name: fileName,
    parents: [folderId],
  }

  const sessionResponse = await apiClient.makeApiRequest({
    path,
    query,
    data,
    method: 'post',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    returnFullResponse: true,
  })

  const uploadPath = sessionResponse.headers['location']

  const fileResponse = await axios.get(fileUri, {
    responseType: 'stream',
  })

  const response = await apiClient.makeApiRequest({
    path: uploadPath,
    method: 'put',
    data: fileResponse.data,
  })

  return { fileId: response.id }
}