export const ID_TYPES = {
  SHARED_DRIVE: 'shared-drive',
  MY_DRIVE: 'my-drive',
  FOLDER: 'folder',
  FILE: 'file',
}

/**
 * Validates and decodes a base64-encoded drive item ID.
 *
 * @param {string} id - A base64-encoded JSON string containing drive item information
 * @returns {Object|null} Decoded object containing { id: string, type: string } or null if no ID provided
 * @throws {Error} Throws 'Invalid parentId' if:
 *   - The string cannot be decoded as base64
 *   - The decoded string is not valid JSON
 *   - The resulting object doesn't have a valid id (string, min 3 chars)
 *   - The resulting object doesn't have a valid type (must be one of ID_TYPES)
 *
 * @example
 * // Valid input format after base64 decoding:
 * // { "id": "abc123", "type": "MY_DRIVE" }
 */
export const validateDriveItemId = (id) => {
  if (!id) {
    return null
  }

  try {
    const stringifiedParentId = atob(id)
    const parsedObject = JSON.parse(stringifiedParentId)
    const validTypes = Object.values(ID_TYPES)

    const hasValidId =
      typeof parsedObject.id === 'string' && parsedObject.id.length >= 3

    const hasValidType =
      typeof parsedObject.type === 'string' &&
      validTypes.includes(parsedObject.type)

    if (!hasValidId || !hasValidType) {
      throw new Error('Invalid parentId')
    }

    return parsedObject
  } catch (error) {
    // throw new Error('Invalid parentId')

    /**
     * Instead of throwing, let provide a fallback which assumed the id is for a file
     * This should allow you to pass id from item event payload directly until we get events for Items collection working properly and having the right id(compound id)
     */

    return {
      id: id,
      type: ID_TYPES.FILE,
    }
  }
}

export const createBase64EncodedId = ({ id, type }) => {
  const stringifiedObject = JSON.stringify({
    id,
    type,
  })

  return btoa(stringifiedObject)
}

export function extractIdFromName(name) {
  return name.split('/').pop()
}

export async function getSharedDrives(apiClient) {
  const response = await apiClient.get('drives', {
    q: '',
    useDomainAdminAccess: false,
    pageSize: 100,
  })

  return response?.drives
}

export async function getLatestDriveActivityTime(
  apiClient,
  driveId,
  activityType,
) {
  const res = await apiClient.post(
    'https://driveactivity.googleapis.com/v2/activity:query',
    {
      filter: `detail.action_detail_case:${activityType}`,
      pageSize: 1,
      ancestorName: `items/${driveId}`,
    },
  )
  return res.activities?.length
    ? res.activities[0].timestamp
    : new Date().toISOString()
}
