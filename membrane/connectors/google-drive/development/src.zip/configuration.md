## How to set up Google Drive OAuth application and get your Client ID and Client Secret

### Project Setup

- Go to the Google [API Console](https://console.cloud.google.com/).
- Create a new project (if you haven't already) by clicking on the "Select a project" drop down menu and selecting “New project”
- Add necessary API’s from the Library (`google drive api`)

In case you'd rather follow the **official Google documentation**, you can find it [here](https://developers.google.com/workspace/guides/create-project).

### Configure the OAuth application

- Click on the OAuth consent screen item in the left sidebar
- Choose the User Type = external
- To be able to put your organization domain into the “Authorized domain” field, have it go through the Google Search console (to make sure it’s authorized and follow the authorization process in case it’s not authorized yet)
- Add the following scopes(To determine the required scopes for your use case, refer to the [API documentation](https://developers.google.com/drive/api/reference/rest/v3)):
  - https://www.googleapis.com/auth/drive
  - https://www.googleapis.com/auth/drive.file
  - https://www.googleapis.com/auth/drive.metadata.readonly
  - https://www.googleapis.com/auth/userinfo.profile
  - https://www.googleapis.com/auth/userinfo.email
  - https://www.googleapis.com/auth/drive.activity.readonly (Make sure to enable the **Drive Activity API** for the project)

You can find the list of the available scopes [here](https://developers.google.com/identity/protocols/oauth2/scopes).

### Generate Credentials

- Select Credentials > Create credentials > OAuth client ID.
- Select Web application as the application type
- Add Authorised redirect URIs: `https://api.integration.app/oauth-callback`. **IMPORTANT**: to get the app approved, you need to use **custom redirect URI** functionality and not mention integration.app anywhere in your app setup
- Click "CREATE"
- Copy the Client ID and Client Secret from the dialog that appears

#### Publish your app

Note that if you want your app to be accessible to other users outside of your organization, you may want to submit it for review. You can find more information about the process [here](https://support.google.com/cloud/answer/9110914?hl=en)

### Configure the app parameters in the integration.app platform

- Add the Google Drive app from store in the Integration.app [console](https://console.integration.app/)
- Click **Configure & Test**
- In the **Parameters** section, select a **Use custom parameters** toggle / **Edit Parameters**
- Fill in **Client Id** and **Client Secret**
- Add scopes your application may require
