export default async function list({ apiClient, cursor }) {
  const response = await apiClient.get('drives', {
    q: '',
    useDomainAdminAccess: false,
    pageToken: cursor,
    pageSize: 100,
  })

  return {
    records: response?.drives,
    cursor: response?.nextPageToken,
  }
}
