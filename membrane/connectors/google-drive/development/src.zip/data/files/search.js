export default async function search({
  apiClient,
  cursor,
  query,
  parameters: { type },
}) {
  const safeQuery = query
    .replace(/\\/g, '\\\\')
    // eslint-disable-next-line quotes
    .replace(/'/g, "\\'")
    .replace(/"/g, '\\"')
  const queryParams = {
    q: `fullText contains '${safeQuery}' and trashed = false`,
    corpora: 'allDrives',
    includeItemsFromAllDrives: true,
    supportsAllDrives: true,
    pageToken: cursor,
  }

  const response = await apiClient.get(
    'https://www.googleapis.com/drive/v2/files',
    queryParams,
  )

  const filteredFiles = response.items.filter((file) =>
    type
      ? type === 'file'
        ? file.mimeType !== 'application/vnd.google-apps.folder'
        : file.mimeType === 'application/vnd.google-apps.folder'
      : file,
  )
  return {
    records: filteredFiles,
    cursor: response.nextPageToken,
  }
}
