import { getSharedDrives, getLatestDriveActivityTime } from 'common'

async function subscribeToDrive(apiClient, driveId, filter = '(EDIT RENAME)') {
  return {
    timestamp: await getLatestDriveActivityTime(apiClient, driveId, filter),
  }
}
export default async function customPullSubscribe({ apiClient }) {
  const subscriptions = {}

  subscriptions['root'] = await subscribeToDrive(apiClient, 'root')

  const sharedDrives = await getSharedDrives(apiClient)
  if (sharedDrives?.length > 0) {
    await Promise.all(
      sharedDrives.map(async (drive) => {
        subscriptions[drive.id] = await subscribeToDrive(apiClient, drive.id)
      }),
    )
  }

  return subscriptions
}
