import { extractIdFromName } from 'common'

async function queryDriveActivities({ apiClient, driveId, timestamp }) {
  return apiClient.post(
    'https://driveactivity.googleapis.com/v2/activity:query',
    {
      filter: `detail.action_detail_case:CREATE AND time > "${timestamp}"`,
      pageSize: 1000,
      ancestorName: `items/${driveId}`,
    },
  )
}

function processActivities({ activities, type, uniqueRecords, events }) {
  activities.forEach((activity) => {
    const target = activity.targets[0].driveItem
    const isFolder = 'folder' in target
    const isFile = 'file' in target

    if (
      type &&
      ((type === 'folder' && !isFolder) || (type === 'file' && !isFile))
    ) {
      return
    }

    // Deduplicate events
    const recordId = extractIdFromName(target.name)
    if (uniqueRecords.has(recordId)) {
      return
    }
    uniqueRecords.add(recordId)

    events.push({
      type: 'created',
      record: { id: recordId },
    })
  })
}

export default async function customPullCollectEvents({
  apiClient,
  parameters: { type },
  state,
}) {
  const events = []
  const subscriptionsState = {}
  const uniqueRecords = new Set()

  for (const [driveId, { timestamp }] of Object.entries(state)) {
    const res = await queryDriveActivities({ apiClient, driveId, timestamp })

    if (!res.activities?.length) {
      subscriptionsState[driveId] = { timestamp: new Date().toISOString() }
      continue
    }

    processActivities({
      activities: res.activities,
      type,
      uniqueRecords,
      events,
    })
    subscriptionsState[driveId] = { timestamp: res.activities[0].timestamp }
  }

  return { events, state: subscriptionsState }
}
