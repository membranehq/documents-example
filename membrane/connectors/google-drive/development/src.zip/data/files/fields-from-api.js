export default function fieldsFromApi({ fields }) {
  /*
  to fetch all files, we're using the v2 API to be able to filter itmes by `isRoot = false`
  for v2 API, some fields are different from v3 API response
   */
  const v2FieldMappings = {
    title: 'name',
    fileSize: 'size',
    alternateLink: 'webViewLink',
    createdDate: 'createdTime',
    modifiedDate: 'modifiedTime',
  }

  Object.entries(v2FieldMappings).forEach(([v2Field, v3Field]) => {
    if (fields[v2Field]) {
      fields[v3Field] = fields[v2Field]
      delete fields[v2Field]
    }
  })

  /**
   * Do not add folderId when the item is directly in the root
   */
  if (fields.parents) {
    if (fields.parents[0]?.id) {
      fields.folderId = fields.parents[0]?.isRoot // isRoot only available in v2 API
        ? undefined
        : fields.parents[0]?.id
    } else {
      fields.folderId = fields.parents[0]
    }
  }

  fields.type =
    fields.mimeType === 'application/vnd.google-apps.folder' ? 'folder' : 'file'

  return fields
}
