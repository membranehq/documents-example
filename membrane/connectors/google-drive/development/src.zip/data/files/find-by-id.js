export default async function findById({ apiClient, id }) {
  const response = await apiClient.get(`files/${id}`, {
    fields: '*',
    supportsAllDrives: true,
  })

  return {
    record: response,
  }
}
