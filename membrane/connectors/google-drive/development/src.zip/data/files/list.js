export default async function list({
  apiClient,
  cursor,
  filter,
  parameters: { type },
}) {
  const fileType = filter?.type ?? type
  let query = 'trashed = false'

  if (filter?.folderId) {
    query += ` and '${filter.folderId}' in parents`
  }

  //filter by file type
  if (fileType) {
    query += ` and mimeType ${
      fileType === 'file' ? '!=' : '='
    } 'application/vnd.google-apps.folder'`
  }

  const queryParams = {
    q: query,
    driveId: filter?.driveId,
    corpora: filter?.driveId ? 'drive' : 'allDrives',
    includeItemsFromAllDrives: true,
    supportsAllDrives: true,
    pageToken: cursor,
    orderBy: 'folder,modifiedDate desc,title',
  }

  const response = await apiClient.get(
    'https://www.googleapis.com/drive/v2/files',
    queryParams,
  )

  /*
    Drive API returns all files from a root folder recursively,
    However, when the folderId is provided,
    We need to generate drilldowns to fetch files from its subfolders recursively
  */
  const drilldowns = filter?.folderId
    ? generateDrillDowns({
        files: response.items,
        filter,
        type,
      })
    : undefined

  return {
    records: response.items,
    cursor: response.nextPageToken,
    drilldowns,
  }
}

function generateDrillDowns({ files, filter, type }) {
  return files
    .filter((file) => file.mimeType === 'application/vnd.google-apps.folder')
    .map((entry) => ({
      parameters: { type },
      filter: {
        driveId: filter?.driveId,
        folderId: entry.id,
        type: filter?.type,
      },
    }))
}
