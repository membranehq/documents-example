export default async function del({ apiClient, id}) {
   await apiClient.delete(`files/${id}`)
}