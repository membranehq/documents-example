import { createBase64EncodedId, ID_TYPES } from 'common'

const isFolderType = (file) =>
  file.mimeType === 'application/vnd.google-apps.folder'

export default async function search({ apiClient, cursor, parameters, query }) {
  const itemTypeParam = parameters?.type

  // Build search query
  let searchQuery = `trashed = false and fullText contains '${query}'`

  // Add type filter if specified
  if (itemTypeParam) {
    searchQuery += ` and mimeType ${
      itemTypeParam === 'file' ? '!=' : '='
    } 'application/vnd.google-apps.folder'`
  }

  const queryParams = {
    q: searchQuery,
    includeItemsFromAllDrives: true,
    supportsAllDrives: true,
    corpora: 'allDrives',
    pageToken: cursor,
  }

  const filesResponse = await apiClient.get(
    'https://www.googleapis.com/drive/v2/files',
    queryParams,
  )

  const records = filesResponse.items.map((item) => ({
    ...item,
    id: createBase64EncodedId({
      id: item.id,
      type: isFolderType(item) ? ID_TYPES.FOLDER : ID_TYPES.FILE,
    }),
    folderId:
      item.parents && item.parents[0]?.id
        ? createBase64EncodedId({
            id: item.parents[0]?.id,
            type: item.parents[0]?.isRoot ? ID_TYPES.MY_DRIVE : ID_TYPES.FOLDER,
          })
        : undefined,
  }))

  return {
    records,
    cursor: filesResponse.nextPageToken,
  }
}
