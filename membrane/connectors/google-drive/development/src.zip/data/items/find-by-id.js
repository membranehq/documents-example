import { validateDriveItemId, ID_TYPES, createBase64EncodedId } from 'common'

export default async function findById({ apiClient, id: driveItemId }) {
  const { id, type } = validateDriveItemId(driveItemId)

  const record = null

  if (type === ID_TYPES.FILE || type === ID_TYPES.FOLDER) {
    const result = await apiClient.get(
      `https://www.googleapis.com/drive/v2/files/${id}`,
      {
        fields: '*',
        supportsAllDrives: true,
      },
    )

    record = {
      ...result,
       id: createBase64EncodedId({
        id: result.id,
        type
      }),
    }
  }

  if (type === ID_TYPES.SHARED_DRIVE) {
    const sharedDrive = await apiClient.get(
      `https://www.googleapis.com/drive/v2/drives/${id}`,
      {
        fields: '*',
        supportsAllDrives: true,
      },
    )

    record = {
      id: createBase64EncodedId({
        id: sharedDrive.id,
        type: ID_TYPES.SHARED_DRIVE,
      }),
      name: myDrive.name,
      type: 'drive',
    }
  }

  if (type === ID_TYPES.MY_DRIVE) {
    const myDrive = await apiClient.get(
      `https://www.googleapis.com/drive/v2/files/root`,
      {
        fields: '*',
        supportsAllDrives: true,
      },
    )

    record = {
      id: createBase64EncodedId({
        id: myDrive.id,
        type: ID_TYPES.MY_DRIVE,
      }),
      name: myDrive.title,
      type: 'drive',
    }
  }

  return {
    record
  }
}
