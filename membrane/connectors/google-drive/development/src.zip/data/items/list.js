import { ID_TYPES, validateDriveItemId, createBase64EncodedId } from 'common'

const MORE_DRIVES_CURSOR_SUFFIX = '-more-drives'

const getSharedDrives = async (apiClient, cursor) => {
  const sharedDrives = await apiClient.get(
    'https://www.googleapis.com/drive/v2/drives',
    {
      pageToken: cursor,
    },
  )

  return {
    cursor: sharedDrives.nextPageToken,
    items: sharedDrives.items.map((item) => ({
      id: createBase64EncodedId({
        id: item.id,
        type: ID_TYPES.SHARED_DRIVE,
      }),
      name: item.name,
      type: 'drive',
    })),
  }
}

const getMyDrive = async (apiClient) => {
  const myDriveResponse = await apiClient.get(
    'https://www.googleapis.com/drive/v2/files/root',
  )

  return {
    id: createBase64EncodedId({
      id: myDriveResponse.id,
      type: ID_TYPES.MY_DRIVE,
    }),
    name: myDriveResponse.title,
    type: 'drive',
  }
}

const isFolderType = (file) =>
  file.mimeType === 'application/vnd.google-apps.folder'

const buildQueryParams = ({ parentIdObject, cursor, typeParam }) => {
  let query = 'trashed = false '
  let corpora = 'allDrives'
  let driveId = ''
  let includeItemsFromAllDrives = true

  // build up corpora, query and includeItemsFromAllDrives based on the parentIdObject
  if (parentIdObject && parentIdObject.type === ID_TYPES.FOLDER) {
    corpora = 'default'
    query += ` and '${parentIdObject.id}' in parents`
    includeItemsFromAllDrives = false
  }

  if (parentIdObject && parentIdObject.type === ID_TYPES.SHARED_DRIVE) {
    corpora = 'drive'
    driveId = parentIdObject.id
    includeItemsFromAllDrives = true
  }

  // If id is myDrive then lets fetch stuff in drive root
  if (parentIdObject && parentIdObject.type === ID_TYPES.MY_DRIVE) {
    corpora = 'default'
    query += "and 'root' in parents"
    includeItemsFromAllDrives = false
  }

  if (typeParam) {
    query += ` and mimeType ${
      typeParam === 'file' ? '!=' : '='
    } 'application/vnd.google-apps.folder'`
  }

  return {
    q: query,
    includeItemsFromAllDrives,
    supportsAllDrives: true,
    pageToken: cursor,
    orderBy: 'folder,modifiedDate desc,title',
    ...(driveId && { driveId }),
    ...(corpora && { corpora }),
  }
}

export default async function list({ apiClient, cursor, filter, parameters }) {
  const itemTypeParam = parameters?.type
  const recursive =
    parameters?.recursive === undefined ? true : parameters?.recursive

  /**
   * If no cursor or filter is provided, we want to go ahead and return
   * all drives available to the user — both shared and "My Drive"
   *
   * We'll use the following endpoints to get all drives
   * - `/drives`  - to get all shared drives
   * - `/files/root` - endpoint to get "My Drive"
   *
   * We'll only return common fields; for now:
   * - id
   * - name
   * - type
   */

  const shouldStartFetchingDrivesFromCursor =
    Boolean(cursor) && String(cursor).startsWith('more-drives:')

  const startFreshDrivesFetch =
    !Boolean(cursor) &&
    !Boolean(filter?.parentId?.trim()) &&
    !['folder', 'file'].includes(itemTypeParam)

  /**
   * FETCHING SHARED DRIVES & MY DRIVE WITH CURSOR IF PROVIDED
   */
  if (startFreshDrivesFetch || shouldStartFetchingDrivesFromCursor) {
    let drives = []
    let cursor = undefined

    if (startFreshDrivesFetch) {
      const myDrive = await getMyDrive(apiClient)
      const sharedDrives = await getSharedDrives(apiClient, cursor)

      drives = [myDrive, ...sharedDrives.items]

      cursor = sharedDrives.cursor
        ? `${sharedDrives.cursor}${MORE_DRIVES_CURSOR_SUFFIX}`
        : recursive
        ? 'drives'
        : undefined
    } else if (shouldStartFetchingDrivesFromCursor) {
      const cleanedCursor = cursor.replace(MORE_DRIVES_CURSOR_SUFFIX, '')

      const sharedDrives = await getSharedDrives(apiClient, cleanedCursor)

      drives = sharedDrives

      if (sharedDrives.cursor) {
        cursor = `${sharedDrives.cursor}${MORE_DRIVES_CURSOR_SUFFIX}`
      }
    }

    return {
      records: drives,
      cursor,
    }
  }

  /**
   * If the cursor is set to "drives" we want to go ahead with normal fetching of files
   * This means the user made a previous call, got back drives and now they want to
   * proceed to get other drive items
   */
  if (cursor === 'drives') {
    cursor = undefined
  }

  let parentIdObject = validateDriveItemId(
    filter?.parentId
      ? filter?.parentId
      : createBase64EncodedId({
          id: 'root',
          type: ID_TYPES.FOLDER,
        }),
  )

  const queryParams = buildQueryParams({
    parentIdObject,
    cursor,
    typeParam: itemTypeParam,
  })

  const filesResponse = await apiClient.get(
    'https://www.googleapis.com/drive/v2/files',
    queryParams,
  )

  const records = filesResponse.items.map((item) => ({
    ...item,
    id: createBase64EncodedId({
      id: item.id,
      type: isFolderType(item) ? ID_TYPES.FOLDER : ID_TYPES.FILE,
    }),
    folderId:
      item.parents && item.parents[0]?.id
        ? createBase64EncodedId({
            id: item.parents[0]?.id,
            type: item.parents[0]?.isRoot ? ID_TYPES.MY_DRIVE : ID_TYPES.FOLDER,
          })
        : undefined,
  }))

  /*
    Drive API returns all files from a root folder recursively,
    However, when the folderId is provided,
    We need to generate drilldowns to fetch files from its subfolders recursively
  */
  const shouldGenerateDrillDowns =
    parentIdObject && parentIdObject.type === ID_TYPES.FOLDER

  const drilldowns = shouldGenerateDrillDowns
    ? generateDrillDowns({
        files: records,
        type: itemTypeParam,
      })
    : undefined

  return {
    records,
    cursor: filesResponse.nextPageToken,
    drilldowns: recursive ? drilldowns : undefined,
  }
}

function generateDrillDowns({ files, type }) {
  return files
    .filter((file) => isFolderType(file))
    .map((file) => ({
      parameters: { type },
      filter: {
        parentId: file.id,
      },
    }))
}
