import { createBase64EncodedId, ID_TYPES } from 'common'

export default function fieldsFromApi({ fields }) {
  /**
   * We are using v2 API to fetch all files, so we need to map the fields to the v3 API fields
   */
  const v2FieldMappings = {
    title: 'name',
    fileSize: 'size',
    alternateLink: 'webViewLink',
    createdDate: 'createdTime',
    modifiedDate: 'modifiedTime',
  }

  Object.entries(v2FieldMappings).forEach(([v2Field, v3Field]) => {
    if (fields[v2Field]) {
      fields[v3Field] = fields[v2Field]
      delete fields[v2Field]
    }
  })

  fields.type =
    fields.type === 'drive'
      ? 'drive'
      : fields.mimeType === 'application/vnd.google-apps.folder'
      ? 'folder'
      : 'file'

  return fields
}
