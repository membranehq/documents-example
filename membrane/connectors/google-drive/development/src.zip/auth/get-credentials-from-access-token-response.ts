export default async function getCredentialsFromTokenResponse({
  tokenResponse,
  credentials,
}): Promise<any> {
  return {
    access_token: tokenResponse.access_token,
    expires_in: tokenResponse.expires_in,
    scope: tokenResponse.scope,
    token_type: tokenResponse.token_type,
    // Google OAuth 2.0 does not return refresh_token in token response
    refresh_token: tokenResponse?.refresh_token ?? credentials?.refresh_token,
  }
}
